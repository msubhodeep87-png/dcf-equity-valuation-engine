"""
Portfolio Risk & Optimization Engine (Modern Portfolio Theory)
-----------------------------------------------------------------
Given a basket of tickers, this script:
    1. Pulls historical prices (live via yfinance, offline fallback otherwise)
    2. Computes annualized returns, volatility, and the correlation matrix
    3. Runs a Monte Carlo simulation (10,000 portfolios) to trace the
       Efficient Frontier
    4. Finds the Max-Sharpe portfolio and the Min-Volatility portfolio
    5. Computes Historical VaR / CVaR (95%) for the optimal portfolio
    6. Exports: efficient_frontier.png, correlation_heatmap.png,
       portfolio_report.xlsx

Run the Streamlit version for an interactive dashboard:
    streamlit run streamlit_app.py

Author: Subho | Built for finance-role portfolio
"""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

TICKERS = ["RELIANCE.NS", "TCS.NS", "HDFCBANK.NS", "INFY.NS", "ITC.NS"]
RISK_FREE_RATE = 0.07          # approx. Indian 10Y G-Sec yield
TRADING_DAYS = 252
NUM_PORTFOLIOS = 10_000
LOOKBACK_DAYS = 504             # ~2 years of daily data


def fetch_price_history(tickers, lookback_days):
    import yfinance as yf
    data = yf.download(tickers, period="2y", progress=False)["Close"]
    data = data.dropna()
    if data.empty or len(data) < 30:
        raise ValueError("Insufficient live data returned")
    return data


def synthetic_price_history(tickers, lookback_days):
    """Offline fallback: generates realistic correlated daily returns using
    a factor model, so the whole pipeline still runs without internet."""
    rng = np.random.default_rng(42)
    n = len(tickers)
    market_factor = rng.normal(0.0004, 0.011, lookback_days)
    betas = rng.uniform(0.6, 1.3, n)
    idio_vol = rng.uniform(0.008, 0.018, n)

    returns = np.zeros((lookback_days, n))
    for i in range(n):
        idio = rng.normal(0, idio_vol[i], lookback_days)
        returns[:, i] = betas[i] * market_factor + idio

    prices = 100 * np.cumprod(1 + returns, axis=0)
    dates = pd.bdate_range(end=pd.Timestamp.today(), periods=lookback_days)
    n_dates = len(dates)
    return pd.DataFrame(prices[:n_dates], index=dates, columns=tickers)


def get_prices(tickers, lookback_days):
    try:
        prices = fetch_price_history(tickers, lookback_days)
        print("[INFO] Using LIVE price data from Yahoo Finance.")
        return prices, "LIVE"
    except Exception as e:
        print(f"[INFO] Live fetch failed ({e}). Using synthetic offline price series so the model still runs.")
        return synthetic_price_history(tickers, lookback_days), "SYNTHETIC / OFFLINE"


def compute_stats(prices):
    daily_returns = prices.pct_change().dropna()
    mean_returns = daily_returns.mean() * TRADING_DAYS
    cov_matrix = daily_returns.cov() * TRADING_DAYS
    return daily_returns, mean_returns, cov_matrix


def portfolio_performance(weights, mean_returns, cov_matrix):
    ret = np.dot(weights, mean_returns)
    vol = np.sqrt(np.dot(weights.T, np.dot(cov_matrix, weights)))
    sharpe = (ret - RISK_FREE_RATE) / vol
    return ret, vol, sharpe


def monte_carlo_frontier(mean_returns, cov_matrix, n_assets, n_portfolios):
    results = np.zeros((3, n_portfolios))
    weight_records = []
    rng = np.random.default_rng(7)
    for i in range(n_portfolios):
        w = rng.random(n_assets)
        w /= w.sum()
        ret, vol, sharpe = portfolio_performance(w, mean_returns, cov_matrix)
        results[:, i] = [ret, vol, sharpe]
        weight_records.append(w)
    return results, weight_records


def historical_var_cvar(daily_returns, weights, confidence=0.95):
    port_returns = daily_returns.dot(weights)
    var = -np.percentile(port_returns, (1 - confidence) * 100)
    cvar = -port_returns[port_returns <= -var].mean()
    return var, cvar


def make_frontier_chart(results, max_sharpe_idx, min_vol_idx, outpath):
    fig, ax = plt.subplots(figsize=(9, 6))
    sc = ax.scatter(results[1], results[0], c=results[2], cmap="viridis", s=8, alpha=0.6)
    ax.scatter(results[1, max_sharpe_idx], results[0, max_sharpe_idx], c="red", marker="*",
               s=400, label="Max Sharpe Portfolio")
    ax.scatter(results[1, min_vol_idx], results[0, min_vol_idx], c="blue", marker="*",
               s=400, label="Min Volatility Portfolio")
    fig.colorbar(sc, label="Sharpe Ratio")
    ax.set_xlabel("Annualized Volatility")
    ax.set_ylabel("Annualized Return")
    ax.set_title("Efficient Frontier — 10,000 Simulated Portfolios")
    ax.legend()
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(outpath, dpi=150)
    plt.close(fig)


def make_correlation_heatmap(daily_returns, outpath):
    fig, ax = plt.subplots(figsize=(7, 6))
    sns.heatmap(daily_returns.corr(), annot=True, cmap="coolwarm", center=0, fmt=".2f", ax=ax)
    ax.set_title("Asset Correlation Matrix")
    fig.tight_layout()
    fig.savefig(outpath, dpi=150)
    plt.close(fig)


def export_report(tickers, mean_returns, cov_matrix, results, weight_records,
                   max_sharpe_idx, min_vol_idx, var, cvar, source, outpath):
    with pd.ExcelWriter(outpath, engine="openpyxl") as writer:
        meta = pd.DataFrame({
            "Metric": ["Data Source", "Risk-Free Rate", "Lookback (trading days)",
                       "Simulations Run", "VaR (95%, daily)", "CVaR (95%, daily)"],
            "Value": [source, f"{RISK_FREE_RATE*100:.1f}%", LOOKBACK_DAYS,
                      NUM_PORTFOLIOS, f"{var*100:.2f}%", f"{cvar*100:.2f}%"]
        })
        meta.to_excel(writer, sheet_name="Summary", index=False)

        stats_df = pd.DataFrame({
            "Ticker": tickers,
            "Annualized Return": mean_returns.values,
            "Annualized Volatility": np.sqrt(np.diag(cov_matrix)),
        })
        stats_df.to_excel(writer, sheet_name="Asset Stats", index=False)

        weights_df = pd.DataFrame({
            "Ticker": tickers,
            "Max Sharpe Weights": weight_records[max_sharpe_idx],
            "Min Volatility Weights": weight_records[min_vol_idx],
        })
        weights_df.to_excel(writer, sheet_name="Optimal Weights", index=False)

        perf_df = pd.DataFrame({
            "Portfolio": ["Max Sharpe", "Min Volatility"],
            "Return": [results[0, max_sharpe_idx], results[0, min_vol_idx]],
            "Volatility": [results[1, max_sharpe_idx], results[1, min_vol_idx]],
            "Sharpe": [results[2, max_sharpe_idx], results[2, min_vol_idx]],
        })
        perf_df.to_excel(writer, sheet_name="Portfolio Performance", index=False)


def main():
    prices, source = get_prices(TICKERS, LOOKBACK_DAYS)
    daily_returns, mean_returns, cov_matrix = compute_stats(prices)

    results, weight_records = monte_carlo_frontier(
        mean_returns.values, cov_matrix.values, len(TICKERS), NUM_PORTFOLIOS
    )
    max_sharpe_idx = results[2].argmax()
    min_vol_idx = results[1].argmin()

    best_weights = weight_records[max_sharpe_idx]
    var, cvar = historical_var_cvar(daily_returns, best_weights)

    make_frontier_chart(results, max_sharpe_idx, min_vol_idx, "efficient_frontier.png")
    make_correlation_heatmap(daily_returns, "correlation_heatmap.png")
    export_report(TICKERS, mean_returns, cov_matrix, results, weight_records,
                   max_sharpe_idx, min_vol_idx, var, cvar, source, "portfolio_report.xlsx")

    print("=" * 60)
    print(f"PORTFOLIO OPTIMIZATION REPORT — Data source: {source}")
    print("=" * 60)
    print(f"Assets: {', '.join(TICKERS)}")
    print("-" * 60)
    print("MAX SHARPE PORTFOLIO")
    for t, w in zip(TICKERS, best_weights):
        print(f"  {t:<15} {w*100:5.1f}%")
    print(f"  Expected Return : {results[0, max_sharpe_idx]*100:.1f}%")
    print(f"  Volatility      : {results[1, max_sharpe_idx]*100:.1f}%")
    print(f"  Sharpe Ratio    : {results[2, max_sharpe_idx]:.2f}")
    print(f"  Daily VaR (95%) : {var*100:.2f}%")
    print(f"  Daily CVaR (95%): {cvar*100:.2f}%")
    print("-" * 60)
    print("MIN VOLATILITY PORTFOLIO")
    for t, w in zip(TICKERS, weight_records[min_vol_idx]):
        print(f"  {t:<15} {w*100:5.1f}%")
    print("-" * 60)
    print("Outputs written: efficient_frontier.png, correlation_heatmap.png, portfolio_report.xlsx")


if __name__ == "__main__":
    main()
