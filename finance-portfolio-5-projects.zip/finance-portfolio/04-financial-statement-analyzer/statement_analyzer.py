"""
Financial Statement Analysis & Red-Flag Detection Tool
-----------------------------------------------------------
Takes a company's multi-year financial statement line items and computes:
    1. Liquidity, Profitability, Leverage, Efficiency ratios (trend view)
    2. Altman Z-Score (bankruptcy / distress risk)
    3. Beneish M-Score (earnings manipulation risk)
    4. A red-flag summary an equity/credit analyst would write up

Works on the bundled sample financials (data/sample_financials.csv) by
default — replace that CSV with any company's real numbers (pulled from
the annual report / screener.in / moneycontrol) to analyze a real company.

Outputs:
    1. ratio_trends.png
    2. zscore_mscore_chart.png
    3. financial_analysis_report.xlsx

Author: Subho | Built for finance-role portfolio
"""

import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

DATA_PATH = "data/sample_financials.csv"


def build_sample_financials(path):
    """5 years of illustrative financial statement line items (₹ Crore).
    Deliberately includes a mild earnings-quality wobble in the latest
    year so the red-flag logic has something to actually flag."""
    years = ["FY21", "FY22", "FY23", "FY24", "FY25"]
    df = pd.DataFrame({
        "year": years,
        "revenue": [12000, 13500, 15200, 17800, 21500],
        "cogs": [7200, 8100, 9100, 10900, 13800],
        "sga_expense": [1800, 1950, 2150, 2450, 2700],
        "depreciation": [600, 650, 700, 760, 790],
        "interest_expense": [350, 360, 340, 380, 420],
        "total_assets": [18000, 19500, 21800, 24600, 29800],
        "current_assets": [7200, 7800, 8700, 9600, 12400],
        "current_liabilities": [4800, 5100, 5600, 6200, 7400],
        "total_liabilities": [9500, 10000, 10800, 11900, 14600],
        "receivables": [1400, 1550, 1750, 2050, 3100],
        "total_debt": [5200, 5300, 5100, 5400, 6100],
        "cash": [1800, 2000, 2300, 2500, 1900],
        "retained_earnings": [4200, 4900, 5750, 6850, 8100],
        "market_cap": [22000, 25500, 31000, 38500, 46000],
    })
    df["gross_profit"] = df["revenue"] - df["cogs"]
    df["ebit"] = df["gross_profit"] - df["sga_expense"] - df["depreciation"]
    df["net_income"] = (df["ebit"] - df["interest_expense"]) * 0.75
    df.to_csv(path, index=False)
    return df


def load_data():
    os.makedirs("data", exist_ok=True)
    if os.path.exists(DATA_PATH):
        return pd.read_csv(DATA_PATH)
    return build_sample_financials(DATA_PATH)


def compute_ratios(df):
    r = pd.DataFrame()
    r["year"] = df["year"]
    r["current_ratio"] = df["current_assets"] / df["current_liabilities"]
    r["gross_margin"] = df["gross_profit"] / df["revenue"]
    r["net_margin"] = df["net_income"] / df["revenue"]
    r["roa"] = df["net_income"] / df["total_assets"]
    r["roe"] = df["net_income"] / (df["total_assets"] - df["total_liabilities"])
    r["debt_to_equity"] = df["total_debt"] / (df["total_assets"] - df["total_liabilities"])
    r["interest_coverage"] = df["ebit"] / df["interest_expense"]
    r["asset_turnover"] = df["revenue"] / df["total_assets"]
    r["receivables_to_revenue"] = df["receivables"] / df["revenue"]
    r["revenue_growth"] = df["revenue"].pct_change()
    r["receivables_growth"] = df["receivables"].pct_change()
    return r


def altman_z_score(df):
    """Altman Z-Score (public manufacturing/industrial firm formula):
    Z = 1.2A + 1.4B + 3.3C + 0.6D + 1.0E
    A=WC/TA, B=RE/TA, C=EBIT/TA, D=MktCap/TotalLiab, E=Sales/TA
    Z>2.99 Safe | 1.81-2.99 Grey zone | <1.81 Distress risk"""
    wc = df["current_assets"] - df["current_liabilities"]
    A = wc / df["total_assets"]
    B = df["retained_earnings"] / df["total_assets"]
    C = df["ebit"] / df["total_assets"]
    D = df["market_cap"] / df["total_liabilities"]
    E = df["revenue"] / df["total_assets"]
    z = 1.2 * A + 1.4 * B + 3.3 * C + 0.6 * D + 1.0 * E
    return z


def beneish_m_score(df):
    """Beneish M-Score (earnings manipulation risk), using simplified
    year-over-year proxies for the 8 standard indices (DSRI, GMI, AQI,
    SGI, DEPI, SGAI, TATA, LVGI). M > -1.78 signals manipulation risk."""
    n = len(df)
    m_scores = [np.nan]  # first year has no prior-year comparison
    for i in range(1, n):
        prev, cur = df.iloc[i - 1], df.iloc[i]

        dsri = (cur["receivables"] / cur["revenue"]) / (prev["receivables"] / prev["revenue"])
        gmi = ((prev["gross_profit"] / prev["revenue"]) /
               (cur["gross_profit"] / cur["revenue"]))
        sgi = cur["revenue"] / prev["revenue"]
        depi = ((prev["depreciation"] / (prev["depreciation"] + prev["total_assets"] * 0.0001)) /
                (cur["depreciation"] / (cur["depreciation"] + cur["total_assets"] * 0.0001)))
        sgai = ((cur["sga_expense"] / cur["revenue"]) / (prev["sga_expense"] / prev["revenue"]))
        lvgi = ((cur["total_liabilities"] / cur["total_assets"]) /
                (prev["total_liabilities"] / prev["total_assets"]))
        tata = (cur["net_income"] - 0) / cur["total_assets"]  # simplified accruals proxy
        aqi = 1.0  # neutral placeholder — needs intangible/PPE breakdown for full precision

        m = (-4.84 + 0.92 * dsri + 0.528 * gmi + 0.404 * aqi + 0.892 * sgi +
             0.115 * depi - 0.172 * sgai + 4.679 * tata - 0.327 * lvgi)
        m_scores.append(m)
    return pd.Series(m_scores, index=df.index)


def generate_red_flags(df, ratios, z_scores, m_scores):
    flags = []
    if ratios["receivables_growth"].iloc[-1] > ratios["revenue_growth"].iloc[-1] * 1.5:
        flags.append("Receivables growing significantly faster than revenue in latest year "
                      "— possible channel stuffing or weakening collections.")
    if ratios["gross_margin"].iloc[-1] < ratios["gross_margin"].iloc[-2]:
        flags.append("Gross margin compressed year-over-year — check input cost pressure "
                      "or pricing power erosion.")
    if z_scores.iloc[-1] < 1.81:
        flags.append("Altman Z-Score in distress zone — elevated bankruptcy risk.")
    elif z_scores.iloc[-1] < 2.99:
        flags.append("Altman Z-Score in grey zone — monitor leverage and liquidity closely.")
    if not pd.isna(m_scores.iloc[-1]) and m_scores.iloc[-1] > -1.78:
        flags.append("Beneish M-Score above the -1.78 threshold — statistically associated "
                      "with higher earnings manipulation risk; warrants deeper audit-quality review.")
    if ratios["debt_to_equity"].iloc[-1] > ratios["debt_to_equity"].iloc[0] * 1.3:
        flags.append("Debt-to-equity has risen meaningfully over the period — leverage risk building.")
    if not flags:
        flags.append("No material red flags detected across the ratios screened.")
    return flags


def make_ratio_chart(ratios, outpath):
    fig, axes = plt.subplots(2, 2, figsize=(11, 8))
    axes[0, 0].plot(ratios["year"], ratios["net_margin"] * 100, marker="o", color="#1f6f4a")
    axes[0, 0].set_title("Net Profit Margin (%)")
    axes[0, 1].plot(ratios["year"], ratios["roe"] * 100, marker="o", color="#d4af37")
    axes[0, 1].set_title("Return on Equity (%)")
    axes[1, 0].plot(ratios["year"], ratios["current_ratio"], marker="o", color="#3a6ea5")
    axes[1, 0].set_title("Current Ratio")
    axes[1, 1].plot(ratios["year"], ratios["receivables_to_revenue"] * 100, marker="o", color="#c0392b")
    axes[1, 1].set_title("Receivables / Revenue (%)")
    for ax in axes.flat:
        ax.grid(alpha=0.3)
    fig.suptitle("Financial Ratio Trends — 5 Year View", fontsize=13)
    fig.tight_layout()
    fig.savefig(outpath, dpi=150)
    plt.close(fig)


def make_score_chart(df, z_scores, m_scores, outpath):
    fig, ax1 = plt.subplots(figsize=(9, 5))
    ax1.bar(df["year"], z_scores, color="#1f6f4a", alpha=0.7, label="Altman Z-Score")
    ax1.axhline(2.99, color="green", linestyle="--", linewidth=1)
    ax1.axhline(1.81, color="red", linestyle="--", linewidth=1)
    ax1.set_ylabel("Altman Z-Score")
    ax2 = ax1.twinx()
    ax2.plot(df["year"], m_scores, color="#d4af37", marker="o", linewidth=2, label="Beneish M-Score")
    ax2.axhline(-1.78, color="orange", linestyle="--", linewidth=1)
    ax2.set_ylabel("Beneish M-Score")
    ax1.set_title("Distress Risk (Z-Score) vs Earnings Manipulation Risk (M-Score)")
    fig.legend(loc="upper left", bbox_to_anchor=(0.1, 0.95))
    fig.tight_layout()
    fig.savefig(outpath, dpi=150)
    plt.close(fig)


def export_report(df, ratios, z_scores, m_scores, flags, outpath):
    with pd.ExcelWriter(outpath, engine="openpyxl") as writer:
        df.to_excel(writer, sheet_name="Raw Financials", index=False)
        ratios.round(4).to_excel(writer, sheet_name="Ratios", index=False)
        scores = pd.DataFrame({"year": df["year"], "Altman_Z": z_scores.round(2),
                                "Beneish_M": m_scores.round(3)})
        scores.to_excel(writer, sheet_name="Risk Scores", index=False)
        pd.DataFrame({"Red Flags": flags}).to_excel(writer, sheet_name="Red Flag Summary", index=False)


def main():
    df = load_data()
    ratios = compute_ratios(df)
    z_scores = altman_z_score(df)
    m_scores = beneish_m_score(df)
    flags = generate_red_flags(df, ratios, z_scores, m_scores)

    make_ratio_chart(ratios, "ratio_trends.png")
    make_score_chart(df, z_scores, m_scores, "zscore_mscore_chart.png")
    export_report(df, ratios, z_scores, m_scores, flags, "financial_analysis_report.xlsx")

    print("=" * 60)
    print("FINANCIAL STATEMENT ANALYSIS & RED-FLAG REPORT")
    print("=" * 60)
    print(ratios.round(3).to_string(index=False))
    print("-" * 60)
    print("Altman Z-Score by year:", dict(zip(df["year"], z_scores.round(2))))
    print("Beneish M-Score by year:", dict(zip(df["year"], m_scores.round(3))))
    print("-" * 60)
    print("RED FLAGS IDENTIFIED:")
    for f in flags:
        print(f"  • {f}")
    print("-" * 60)
    print("Outputs written: ratio_trends.png, zscore_mscore_chart.png, financial_analysis_report.xlsx")


if __name__ == "__main__":
    main()
