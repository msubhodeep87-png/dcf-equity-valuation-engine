"""
Streamlit Dashboard — Portfolio Risk & Optimization
-----------------------------------------------------
Interactive front-end for portfolio_optimizer.py.
Run with:  streamlit run streamlit_app.py
"""

import streamlit as st
import numpy as np
import pandas as pd
import plotly.graph_objects as go

from portfolio_optimizer import (
    get_prices, compute_stats, monte_carlo_frontier,
    historical_var_cvar, RISK_FREE_RATE, NUM_PORTFOLIOS
)

st.set_page_config(page_title="Portfolio Risk & Optimization Dashboard", layout="wide")
st.title("📊 Portfolio Risk & Optimization Dashboard")
st.caption("Modern Portfolio Theory · Monte Carlo Efficient Frontier · VaR/CVaR")

with st.sidebar:
    st.header("Configuration")
    tickers_input = st.text_input(
        "Tickers (comma-separated, NSE format)",
        "RELIANCE.NS, TCS.NS, HDFCBANK.NS, INFY.NS, ITC.NS"
    )
    n_sim = st.slider("Number of simulated portfolios", 1000, 20000, NUM_PORTFOLIOS, step=1000)
    confidence = st.slider("VaR / CVaR confidence level", 0.90, 0.99, 0.95, step=0.01)
    run_btn = st.button("Run Optimization", type="primary")

tickers = [t.strip() for t in tickers_input.split(",") if t.strip()]

if run_btn:
    with st.spinner("Pulling data and running Monte Carlo simulation..."):
        prices, source = get_prices(tickers, 504)
        daily_returns, mean_returns, cov_matrix = compute_stats(prices)
        results, weight_records = monte_carlo_frontier(
            mean_returns.values, cov_matrix.values, len(tickers), n_sim
        )
        max_sharpe_idx = results[2].argmax()
        min_vol_idx = results[1].argmin()
        best_weights = weight_records[max_sharpe_idx]
        var, cvar = historical_var_cvar(daily_returns, best_weights, confidence)

    st.success(f"Data source: {source}")

    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Expected Return", f"{results[0, max_sharpe_idx]*100:.1f}%")
    col2.metric("Volatility", f"{results[1, max_sharpe_idx]*100:.1f}%")
    col3.metric("Sharpe Ratio", f"{results[2, max_sharpe_idx]:.2f}")
    col4.metric(f"VaR ({int(confidence*100)}%, daily)", f"{var*100:.2f}%")

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=results[1], y=results[0], mode="markers",
        marker=dict(size=4, color=results[2], colorscale="Viridis", showscale=True,
                    colorbar=dict(title="Sharpe")),
        name="Simulated Portfolios"
    ))
    fig.add_trace(go.Scatter(
        x=[results[1, max_sharpe_idx]], y=[results[0, max_sharpe_idx]],
        mode="markers", marker=dict(size=18, color="red", symbol="star"),
        name="Max Sharpe"
    ))
    fig.add_trace(go.Scatter(
        x=[results[1, min_vol_idx]], y=[results[0, min_vol_idx]],
        mode="markers", marker=dict(size=18, color="blue", symbol="star"),
        name="Min Volatility"
    ))
    fig.update_layout(
        title="Efficient Frontier", xaxis_title="Volatility", yaxis_title="Return",
        height=550, template="plotly_dark"
    )
    st.plotly_chart(fig, use_container_width=True)

    colA, colB = st.columns(2)
    with colA:
        st.subheader("Max Sharpe Allocation")
        st.dataframe(pd.DataFrame({"Ticker": tickers, "Weight %": (best_weights * 100).round(1)}))
    with colB:
        st.subheader("Min Volatility Allocation")
        st.dataframe(pd.DataFrame({
            "Ticker": tickers,
            "Weight %": (weight_records[min_vol_idx] * 100).round(1)
        }))

    st.subheader("Correlation Matrix")
    st.dataframe(daily_returns.corr().round(2))
else:
    st.info("Set your tickers in the sidebar and click **Run Optimization**.")
