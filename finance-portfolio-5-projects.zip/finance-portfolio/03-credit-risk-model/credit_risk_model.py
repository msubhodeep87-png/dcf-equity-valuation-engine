"""
Credit Risk / Loan Default Prediction Model
-----------------------------------------------
Builds a binary classifier (Logistic Regression + XGBoost) to predict
loan default probability from borrower features, fully self-contained
with a synthetic but realistically-structured dataset (no external
download needed — swap in any real credit dataset, e.g. Kaggle's
"Give Me Some Credit" or LendingClub, by replacing load_data()).

Outputs:
    1. data/synthetic_credit_data.csv      (the dataset used)
    2. roc_curve.png                       (model comparison)
    3. feature_importance.png              (XGBoost feature importance)
    4. credit_risk_report.xlsx             (metrics + scored applicants)

Author: Subho | Built for finance-role portfolio
"""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, roc_curve, classification_report, confusion_matrix
import xgboost as xgb

N_SAMPLES = 5000
RANDOM_STATE = 42


def generate_synthetic_credit_data(n=N_SAMPLES, seed=RANDOM_STATE):
    """Generates a synthetic but realistic credit-risk dataset:
    age, income, loan amount, credit history length, debt-to-income,
    number of past delinquencies, employment length -> default flag."""
    rng = np.random.default_rng(seed)

    age = rng.integers(21, 65, n)
    annual_income = rng.normal(700_000, 350_000, n).clip(150_000, None)   # ₹
    loan_amount = rng.normal(800_000, 500_000, n).clip(50_000, None)      # ₹
    credit_history_years = rng.integers(0, 25, n)
    employment_years = rng.integers(0, 30, n)
    past_delinquencies = rng.poisson(0.4, n)
    dti = (loan_amount / (annual_income + 1)).clip(0, 5)
    interest_rate = rng.normal(11, 3, n).clip(7, 24)

    # latent default score driven by realistic risk factors
    risk_score = (
        0.9 * dti
        + 0.35 * past_delinquencies
        - 0.015 * credit_history_years
        - 0.01 * employment_years
        + 0.02 * (interest_rate - 11)
        - 0.0000015 * (annual_income - 700_000)
        + rng.normal(0, 0.6, n)
    )
    default_prob = 1 / (1 + np.exp(-(risk_score - 2.1)))
    default = (rng.random(n) < default_prob).astype(int)

    df = pd.DataFrame({
        "age": age,
        "annual_income": annual_income.round(0),
        "loan_amount": loan_amount.round(0),
        "credit_history_years": credit_history_years,
        "employment_years": employment_years,
        "past_delinquencies": past_delinquencies,
        "debt_to_income": dti.round(3),
        "interest_rate": interest_rate.round(2),
        "default": default,
    })
    return df


def load_data():
    df = generate_synthetic_credit_data()
    df.to_csv("data/synthetic_credit_data.csv", index=False)
    return df


def train_models(df):
    features = [c for c in df.columns if c != "default"]
    X = df[features]
    y = df["default"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=RANDOM_STATE, stratify=y
    )

    scaler = StandardScaler()
    X_train_s = scaler.fit_transform(X_train)
    X_test_s = scaler.transform(X_test)

    logreg = LogisticRegression(max_iter=1000, class_weight="balanced")
    logreg.fit(X_train_s, y_train)
    logreg_probs = logreg.predict_proba(X_test_s)[:, 1]

    xgb_model = xgb.XGBClassifier(
        n_estimators=200, max_depth=4, learning_rate=0.05,
        eval_metric="auc", random_state=RANDOM_STATE
    )
    xgb_model.fit(X_train, y_train)
    xgb_probs = xgb_model.predict_proba(X_test)[:, 1]

    return {
        "features": features,
        "X_test": X_test, "y_test": y_test,
        "logreg": logreg, "logreg_probs": logreg_probs,
        "xgb_model": xgb_model, "xgb_probs": xgb_probs,
    }


def evaluate(results):
    metrics = {}
    for name, probs in [("Logistic Regression", results["logreg_probs"]),
                         ("XGBoost", results["xgb_probs"])]:
        auc = roc_auc_score(results["y_test"], probs)
        preds = (probs > 0.5).astype(int)
        report = classification_report(results["y_test"], preds, output_dict=True)
        metrics[name] = {"AUC": auc, "report": report}
    return metrics


def make_roc_chart(results, outpath):
    fig, ax = plt.subplots(figsize=(7, 6))
    for name, probs, color in [
        ("Logistic Regression", results["logreg_probs"], "#1f6f4a"),
        ("XGBoost", results["xgb_probs"], "#d4af37"),
    ]:
        fpr, tpr, _ = roc_curve(results["y_test"], probs)
        auc = roc_auc_score(results["y_test"], probs)
        ax.plot(fpr, tpr, label=f"{name} (AUC={auc:.3f})", color=color, linewidth=2)
    ax.plot([0, 1], [0, 1], linestyle="--", color="gray")
    ax.set_xlabel("False Positive Rate")
    ax.set_ylabel("True Positive Rate")
    ax.set_title("ROC Curve — Default Prediction Models")
    ax.legend()
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(outpath, dpi=150)
    plt.close(fig)


def make_feature_importance_chart(results, outpath):
    importances = results["xgb_model"].feature_importances_
    features = results["features"]
    order = np.argsort(importances)
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.barh(np.array(features)[order], importances[order], color="#1f6f4a")
    ax.set_title("XGBoost Feature Importance — Default Drivers")
    ax.set_xlabel("Importance")
    fig.tight_layout()
    fig.savefig(outpath, dpi=150)
    plt.close(fig)


def export_report(results, metrics, outpath):
    with pd.ExcelWriter(outpath, engine="openpyxl") as writer:
        summary_rows = []
        for name, m in metrics.items():
            summary_rows.append({
                "Model": name,
                "AUC": round(m["AUC"], 4),
                "Precision (default=1)": round(m["report"]["1"]["precision"], 3),
                "Recall (default=1)": round(m["report"]["1"]["recall"], 3),
                "F1 (default=1)": round(m["report"]["1"]["f1-score"], 3),
                "Accuracy": round(m["report"]["accuracy"], 3),
            })
        pd.DataFrame(summary_rows).to_excel(writer, sheet_name="Model Comparison", index=False)

        scored = results["X_test"].copy()
        scored["actual_default"] = results["y_test"].values
        scored["xgb_predicted_prob"] = results["xgb_probs"]
        scored["risk_band"] = pd.cut(
            scored["xgb_predicted_prob"], bins=[0, 0.2, 0.5, 0.8, 1.0],
            labels=["Low", "Medium", "High", "Very High"]
        )
        scored.sort_values("xgb_predicted_prob", ascending=False).head(200).to_excel(
            writer, sheet_name="Scored Applicants (Top 200)", index=False
        )


def main():
    df = load_data()
    results = train_models(df)
    metrics = evaluate(results)

    make_roc_chart(results, "roc_curve.png")
    make_feature_importance_chart(results, "feature_importance.png")
    export_report(results, metrics, "credit_risk_report.xlsx")

    print("=" * 60)
    print("CREDIT RISK DEFAULT PREDICTION MODEL")
    print("=" * 60)
    print(f"Dataset size: {len(df)} applicants | Default rate: {df['default'].mean()*100:.1f}%")
    print("-" * 60)
    for name, m in metrics.items():
        print(f"{name:<22} AUC: {m['AUC']:.3f} | Accuracy: {m['report']['accuracy']:.3f} | "
              f"Recall(default): {m['report']['1']['recall']:.3f}")
    print("-" * 60)
    print("Top 5 risk drivers (XGBoost):")
    importances = results["xgb_model"].feature_importances_
    feat_imp = sorted(zip(results["features"], importances), key=lambda x: -x[1])[:5]
    for f, imp in feat_imp:
        print(f"  {f:<22} {imp:.3f}")
    print("-" * 60)
    print("Outputs written: data/synthetic_credit_data.csv, roc_curve.png,")
    print("                 feature_importance.png, credit_risk_report.xlsx")


if __name__ == "__main__":
    main()
