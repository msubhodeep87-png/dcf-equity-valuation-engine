# Financial Statement Analysis & Red-Flag Detection Tool

An automated equity/credit research tool that turns 5 years of financial statement line items into a full ratio analysis, an Altman Z-Score (bankruptcy risk), a Beneish M-Score (earnings manipulation risk), and a written red-flag summary — the kind of write-up a junior equity research or credit analyst produces.

## What it does
- Computes liquidity, profitability, leverage, and efficiency ratio trends across 5 years
- Calculates the **Altman Z-Score** to flag bankruptcy/distress risk
- Calculates the **Beneish M-Score** to flag earnings manipulation risk
- Auto-generates a red-flag narrative (e.g. "receivables growing faster than revenue," "margin compression," "M-Score above threshold") — the exact kind of forensic accounting checks used in equity research and credit underwriting
- Ships with a bundled 5-year sample dataset that deliberately includes a realistic earnings-quality wobble in the final year, so the red-flag logic has something real to catch

## Why this matters for a finance role
Ratio analysis and forensic screens (Z-Score, M-Score) are core to fundamental equity research, credit analysis, and CFA Level 2's Financial Statement Analysis curriculum. This project proves you can go beyond calculating ratios to actually interpreting them — the skill that separates an analyst from a spreadsheet.

## Tech stack
Python · pandas · numpy · matplotlib

## Setup
```bash
pip install -r requirements.txt
python statement_analyzer.py
```
To analyze a real company: replace `data/sample_financials.csv` with actual line items pulled from the company's annual report, screener.in, or moneycontrol (same column structure).

## Outputs
- `ratio_trends.png` — net margin, ROE, current ratio, receivables/revenue trends
- `zscore_mscore_chart.png` — Altman Z-Score and Beneish M-Score by year, with risk thresholds marked
- `financial_analysis_report.xlsx` — raw financials, ratios, risk scores, red-flag summary

## How to talk about this in an interview
- "I built a financial statement analyzer that computes the Altman Z-Score and Beneish M-Score alongside standard ratio trends, and auto-generates red flags — for example, it flagged a receivables spike outpacing revenue growth, which is a classic early warning for channel stuffing or weakening collections."
- Be ready to explain: what each component of the Z-Score formula represents (working capital, retained earnings, EBIT, market cap, sales — all scaled by total assets), why M-Score above -1.78 is the conventional threshold for manipulation risk (it's calibrated from Beneish's original sample of known fraud cases), and that these are screening tools, not proof — they flag where to dig deeper, not a verdict.
- If asked to extend it: add peer/industry benchmarking (ratios mean nothing in isolation), or pull the data directly from XBRL filings instead of a manual CSV.
