# Finance Portfolio — 5 Projects

Five working, end-to-end finance/data projects built to demonstrate the analytical + technical skill set finance recruiters (equity research, credit risk, asset management, banking, RBI Grade B / DEPR) actually screen for. Each project is a self-contained GitHub repo: runnable code, a README, sample outputs, and an interview-ready explanation of what it shows.

| # | Project | Role relevance |
|---|---|---|
| 1 | [Automated DCF Equity Valuation Engine](01-equity-valuation-dcf/) | Equity research, IB, CFA L2 |
| 2 | [Portfolio Risk & Optimization Dashboard](02-portfolio-risk-optimizer/) | Asset/wealth management, quant |
| 3 | [Credit Risk Default Prediction Model](03-credit-risk-model/) | Banking, NBFC credit risk |
| 4 | [Financial Statement Red-Flag Detector](04-financial-statement-analyzer/) | Equity research, credit analysis |
| 5 | [RBI Macro-Policy & Market Dashboard](05-rbi-macro-dashboard/) | RBI Grade B / DEPR, economics research |

See `MASTER_PLAN.md` in this folder for the full build order, GitHub setup, resume bullets, and interview prep for all 5.

## Quick start (any project)
```bash
cd <project-folder>
pip install -r requirements.txt
python <script_name>.py
```
Every script runs end-to-end with zero external setup — each one falls back to a realistic bundled/synthetic dataset if it can't reach a live API, so nothing ever crashes on a fresh clone.
