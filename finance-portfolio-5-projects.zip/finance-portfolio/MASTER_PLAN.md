# Finance Portfolio — Master Plan

Built for: B.Com Honours + CFA + CIMA track, targeting CFA L2 / RBI Grade B and a CFO-track career path.

---

## 1. Why these 5 projects (the analysis)

Finance recruiters screening GitHub profiles fall into roughly 4 buckets — equity research / IB, asset & wealth management, banking & credit risk, and economic/policy research (RBI, regulators, think tanks). A portfolio that only proves you can code (e.g. 5 web apps) gets ignored by finance hiring managers; a portfolio that only has spreadsheets gets ignored by anyone screening for technical skill. The gap that gets you noticed is **finance domain knowledge expressed as working code** — which is exactly what's rare at the fresher/early-career level in India right now (most B.Com/finance students submit Excel-only projects; most CS students submit projects with zero finance logic).

These 5 were chosen to cover all 4 hiring buckets so that **whichever team looks at your profile finds something directly relevant to their function**:

| Project | Bucket covered | Core technique |
|---|---|---|
| DCF Valuation Engine | Equity research / IB | Discounted Cash Flow, sensitivity analysis |
| Portfolio Optimizer | Asset/wealth management, quant | Modern Portfolio Theory, Monte Carlo, VaR |
| Credit Risk Model | Banking, NBFC, credit risk | Classification ML, PD modeling |
| Statement Red-Flag Detector | Equity research, credit, audit | Ratio analysis, Z-Score, M-Score (forensic accounting) |
| RBI Macro Dashboard | RBI Grade B / DEPR, economics research | Macro-to-market correlation, policy analysis |

Project 5 specifically targets your RBI Grade B goal — DEPR interviews routinely probe "how does a repo rate change transmit to growth and markets," and walking in with a dashboard you built on exactly that question is a meaningful differentiator versus reciting it from a textbook.

---

## 2. Build order & timeline (4 weeks, ~6-8 hrs/week)

Don't build all 5 in one weekend — recruiters can tell when every commit lands on the same day. Spread it out; it also reads as sustained effort, not a one-time resume-padding exercise.

| Week | Task |
|---|---|
| **Week 1** | Build + push Project 1 (DCF). Run it on 3 real companies (e.g. RELIANCE.NS, TCS.NS, an HDFC group stock) and save those outputs as proof in the repo. |
| **Week 2** | Build + push Project 3 (Credit Risk). This is the most "technical-looking" one — do it early so your GitHub already shows ML skill while you're still building the others. |
| **Week 3** | Build + push Project 2 (Portfolio Optimizer) and Project 4 (Statement Analyzer). |
| **Week 4** | Build + push Project 5 (RBI Macro Dashboard). Pin all 5 repos. Update LinkedIn + resume. Start applying. |

Commit in small increments (data loading → model → charts → README) rather than one giant commit — your commit history is itself a signal recruiters and ATS-adjacent tools sometimes check.

---

## 3. How to push each project to GitHub (copy-paste steps)

```bash
# 1. Create the repo on GitHub first (via github.com/new), e.g. "dcf-equity-valuation-engine"
#    Do NOT initialize it with a README (you already have one)

# 2. From inside the project folder on your machine:
cd 01-equity-valuation-dcf
git init
git add .
git commit -m "Initial commit: DCF equity valuation engine with sensitivity analysis"
git branch -M main
git remote add origin https://github.com/<your-username>/dcf-equity-valuation-engine.git
git push -u origin main
```

Repeat for each of the 5 folders with its own repo name:
- `dcf-equity-valuation-engine`
- `portfolio-risk-optimizer`
- `credit-risk-default-model`
- `financial-statement-redflag-detector`
- `rbi-macro-policy-dashboard`

### Make each repo look complete (do this for all 5)
1. Add a **repo description** (1 line, shown under the repo name on GitHub) — copy the first sentence of each README's "What it does."
2. Add **topics/tags**: `finance`, `python`, `quantitative-finance`, `data-science`, plus one specific tag per project (`dcf`, `portfolio-optimization`, `credit-risk`, `financial-analysis`, `macroeconomics`).
3. Upload the generated PNG charts to the repo's root or an `outputs/` folder so visitors see results without running anything — **this matters more than the code itself for a 10-second recruiter skim.**
4. Pin all 5 repos on your GitHub profile (Profile → Customize your pins).

---

## 4. Resume bullets (copy-paste, then tailor numbers if you re-run with different data)

```
• Built an automated DCF valuation engine (Python) pulling live financials via API,
  producing intrinsic value estimates and a WACC/growth sensitivity grid across 5
  WACC and 4 growth scenarios — exported to a stakeholder-ready Excel workbook.

• Built a Modern Portfolio Theory optimizer running 10,000-iteration Monte Carlo
  simulation to trace the efficient frontier; identified Max Sharpe and Min Volatility
  portfolios and computed 95% VaR/CVaR; shipped as an interactive Streamlit dashboard.

• Built a credit default prediction model (Logistic Regression + XGBoost) achieving
  ~0.79 ROC-AUC on a 5,000-applicant dataset; identified debt-to-income and
  delinquency history as the top default drivers via feature importance analysis.

• Built a financial statement analysis tool computing Altman Z-Score and Beneish
  M-Score across 5 years of financials, with automated red-flag detection (e.g.
  receivables growth outpacing revenue) — replicating forensic accounting checks
  used in equity research and credit underwriting.

• Built a macro-policy dashboard tracking RBI repo rate, CPI inflation, and GDP
  growth against Nifty 50 returns across 21 quarters, with auto-generated policy
  commentary tied to India's flexible inflation targeting framework.
```

Put these under a **"Finance & Data Projects"** section on your resume — not buried under "Technical Skills." Link each bullet's project name to its GitHub repo if your resume format/PDF allows hyperlinks.

---

## 5. How to represent this on LinkedIn

Post one project per week as you finish it (not all 5 at once — that reads as a one-off). Structure for each post:
1. One-line hook: the business question it answers (e.g. "Is RELIANCE trading above or below its intrinsic value right now?")
2. The chart/output image (always include — visual posts get far more reach)
3. 2-3 lines on the method and what you found
4. GitHub link in the first comment (LinkedIn suppresses reach on posts with outbound links in the body)

---

## 6. Interview prep — the 5 questions you WILL get

1. **"Walk me through one of your projects."**
   Pick the one most relevant to the role you're interviewing for (DCF for IB/equity research, Credit Risk for banking, Macro Dashboard for RBI). Structure your answer: the question it answers → the method → one specific number/finding → one limitation you're aware of. Never just describe the code.

2. **"What would you change if you had more time / real client data?"**
   Each project's README has a "How to extend it" line at the end — memorize your strongest project's answer here. This question filters for whether you actually understand the model or just followed a tutorial.

3. **"Why does [specific assumption] matter?"**
   E.g. "why does WACC matter so much in your DCF," "why use AUC instead of accuracy for the credit model," "why does the Beneish M-Score use -1.78 as the threshold." Each README's interview section has this answer pre-written — review all 5 before any interview, not just the one you'll lead with.

4. **"What's a limitation of this model?"**
   Always have one ready per project (DCF: extremely sensitive to terminal growth/WACC; Portfolio Optimizer: assumes historical returns predict future returns; Credit Model: synthetic/historical data may not reflect new economic regimes; Z/M-Score: screening tools, not proof; Macro Dashboard: correlation isn't causation). Saying "it has no limitations" is a worse answer than naming one honestly.

5. **"How is this different from just using a template / ChatGPT?"**
   Be ready to explain ONE design decision you'd defend — e.g. why you chose Logistic Regression *and* XGBoost rather than just the best-performing one (regulatory explainability trade-off), or why the DCF has a sensitivity table instead of a single point estimate (DCF outputs are not single numbers, they're ranges).

---

## 7. Where to apply once this is live

- **Equity research / IB analyst (associate/intern level):** lead with Project 1 (DCF) and Project 4 (Statement Analyzer)
- **Asset/wealth management, quant-adjacent roles:** lead with Project 2 (Portfolio Optimizer)
- **Banks, NBFCs, credit risk teams:** lead with Project 3 (Credit Risk Model)
- **RBI Grade B (DEPR especially), economic research, think tanks:** lead with Project 5 (Macro Dashboard) — mention it directly in your RBI Grade B interview if asked about your interest in monetary policy

This same portfolio also strengthens your CFA Level 2 narrative in interviews generally — DCF (Equity Valuation), Portfolio Optimizer (Portfolio Management), and Statement Analyzer (FSA) map directly onto 3 of CFA L2's heaviest-weighted topic areas. Mentioning that connection explicitly tells an interviewer you're not just job-hunting, you're building toward the CFO-track plan deliberately.
