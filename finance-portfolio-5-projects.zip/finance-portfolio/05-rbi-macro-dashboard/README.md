# RBI Macro-Policy & Market Correlation Dashboard

A macroeconomic research dashboard tracking RBI's repo rate, CPI inflation, GDP growth, and forex reserves against Nifty 50 performance — built specifically to demonstrate the research/analytical skill set RBI Grade B (especially DEPR) and economic research roles look for.

## What it does
- Tracks repo rate, CPI inflation (vs RBI's 2-6% tolerance band), GDP growth, and forex reserves over 21 quarters
- Classifies each quarter's policy stance (Tightening / Easing / Hold) from the repo rate change
- Computes the **correlation matrix** between macro indicators and Nifty 50 quarterly returns
- Auto-generates **policy commentary** — e.g. flags when CPI breaches the upper tolerance band, or when the RBI is mid-tightening-cycle — in the tone of an RBI Monetary Policy Committee resolution writeup
- Includes a Streamlit version for interactive exploration

## Why this matters for an RBI Grade B / finance research role
This is the exact analytical lens DEPR (Department of Economic and Policy Research) and treasury/economics desks use: connecting monetary policy decisions to inflation targeting and market outcomes. Building this shows you understand the RBI's flexible inflation targeting framework in a way that goes beyond textbook definitions.

## Tech stack
Python · pandas · numpy · matplotlib · seaborn · streamlit

## Setup
```bash
pip install -r requirements.txt

# Command-line report:
python macro_dashboard.py

# Interactive dashboard:
streamlit run streamlit_app.py
```
To go live: replace `data/rbi_macro_data.csv` with the latest releases from rbi.org.in (Monetary Policy Committee resolutions) and mospi.gov.in (CPI prints).

## Outputs
- `macro_trends.png` — 4-panel view: repo rate, CPI vs target band, GDP growth, Nifty 50
- `policy_market_correlation.png` — correlation heatmap
- `macro_dashboard_report.xlsx` — full data, correlation matrix, auto-generated commentary

## How to talk about this in an interview
- "I built a dashboard tracking RBI's policy rate, CPI inflation against the 2-6% target band, and GDP growth against Nifty 50 returns, with auto-generated policy commentary — to practice the kind of macro-to-market analysis DEPR and economic research roles do."
- Be ready to explain: India's flexible inflation targeting framework (4% CPI target, +/-2% band), the lag between a repo rate change and its transmission to growth/markets (typically 2-3 quarters), and why correlation alone doesn't imply causation — repo decisions are themselves *reactions* to inflation and growth, not independent of them.
- If asked to extend it: add the 10-year G-Sec yield and USD/INR as additional series, or build an event-study around actual MPC meeting dates rather than quarter-end snapshots.
