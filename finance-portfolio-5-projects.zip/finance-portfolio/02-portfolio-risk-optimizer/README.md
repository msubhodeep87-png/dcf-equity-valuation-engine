# Portfolio Risk & Optimization Dashboard (Modern Portfolio Theory)

A quantitative portfolio construction tool: Monte Carlo Efficient Frontier simulation, Max-Sharpe and Min-Volatility portfolio identification, and Value-at-Risk / Conditional VaR — wrapped in an interactive Streamlit dashboard.

## What it does
- Pulls historical price data for any basket of tickers
- Computes annualized return, volatility, and the asset correlation matrix
- Runs a **10,000-portfolio Monte Carlo simulation** to trace the Efficient Frontier
- Identifies the **Max Sharpe Ratio** portfolio and the **Min Volatility** portfolio
- Computes **Historical VaR and CVaR (95%)** for the optimal portfolio
- Interactive Streamlit dashboard where you can change tickers and re-run live

## Why this matters for a finance role
This is core Modern Portfolio Theory (Markowitz) — directly tested in CFA Level 1/2 Portfolio Management. It's the exact workflow used by asset management and wealth management teams to build model portfolios, and risk teams to size VaR limits. Showing both the model AND a usable dashboard signals you can build tools analysts would actually use, not just run a one-off script.

## Tech stack
Python · pandas · numpy · matplotlib · seaborn · plotly · streamlit · yfinance

## Setup
```bash
pip install -r requirements.txt

# Command-line report:
python portfolio_optimizer.py

# Interactive dashboard:
streamlit run streamlit_app.py
```
Change the basket in `portfolio_optimizer.py`:
```python
TICKERS = ["RELIANCE.NS", "TCS.NS", "HDFCBANK.NS", "INFY.NS", "ITC.NS"]
```
If you're offline, the script automatically falls back to a synthetic but realistically-correlated price series so the whole pipeline still runs and produces a real efficient frontier.

## Outputs
- `efficient_frontier.png` — 10,000 simulated portfolios, color-coded by Sharpe Ratio
- `correlation_heatmap.png` — asset correlation matrix
- `portfolio_report.xlsx` — asset stats, optimal weights, portfolio performance

## How to talk about this in an interview
- "I built a Monte Carlo portfolio optimizer that simulates 10,000 random allocations to trace the efficient frontier, then identifies the Max Sharpe and Min Volatility portfolios — with VaR/CVaR for downside risk."
- Be ready to explain: what Sharpe Ratio measures (excess return per unit of risk), why diversification reduces portfolio volatility below the weighted average of individual asset volatilities (correlation < 1), and the difference between VaR (a threshold loss) and CVaR (the average loss beyond that threshold — what regulators increasingly prefer because it captures tail risk).
- If asked to extend it: add a Black-Litterman layer to incorporate your own return views instead of pure historical means, or constrain weights (e.g., sector caps, no short-selling) to make it deployable for a real mandate.
