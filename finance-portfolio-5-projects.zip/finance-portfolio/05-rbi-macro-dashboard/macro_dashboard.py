"""
RBI Macro-Policy & Market Correlation Dashboard
----------------------------------------------------
Built specifically for an RBI Grade B / DEPR-style research angle:
tracks key Indian macro indicators (repo rate, CPI inflation, GDP growth,
forex reserves) against equity market performance, and produces a
policy-commentary-ready dashboard.

Data: bundled historical series (data/rbi_macro_data.csv) based on
publicly published RBI/MOSPI release patterns through the knowledge
cutoff. Update the CSV with the latest RBI Monetary Policy Committee
releases (rbi.org.in) and MOSPI CPI prints for a live, current dashboard.

Outputs:
    1. macro_trends.png
    2. policy_market_correlation.png
    3. macro_dashboard_report.xlsx

Run the Streamlit version for an interactive dashboard:
    streamlit run streamlit_app.py

Author: Subho | Built for finance-role / RBI Grade B portfolio
"""

import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

DATA_PATH = "data/rbi_macro_data.csv"


def build_macro_dataset(path):
    """Quarterly macro series, FY21-Q1 through FY26-Q1 (illustrative,
    structured to mirror real RBI/MOSPI release patterns — replace with
    live pulls from rbi.org.in / mospi.gov.in / FRED for production use)."""
    quarters = [f"FY{y}-Q{q}" for y in range(21, 26) for q in range(1, 5)] + ["FY26-Q1"]
    n = len(quarters)
    rng = np.random.default_rng(11)

    repo_rate = [4.0]*4 + [4.0, 4.4, 5.4, 5.9] + [6.25, 6.5, 6.5, 6.5] + \
                [6.5, 6.5, 6.25, 6.25] + [6.0, 5.75, 5.5, 5.5] + [5.5]
    cpi_inflation = [6.2, 6.6, 5.6, 4.9, 6.3, 7.0, 7.4, 6.2, 5.7, 4.6, 5.0, 5.7,
                     4.9, 4.7, 5.4, 5.1, 4.3, 3.5, 3.1, 3.3, 3.4]
    gdp_growth = [1.6, 20.1, 8.4, 5.4, 4.0, 13.5, 6.2, 4.5, 7.8, 7.6, 8.1, 8.4,
                  7.8, 6.7, 5.4, 7.4, 7.4, 7.8, 6.5, 6.8, 6.9]
    forex_reserves_usd_bn = [577, 588, 590, 607, 619, 588, 532, 562, 578, 596,
                              586, 619, 646, 651, 657, 640, 660, 685, 690, 700, 712]
    nifty50_qend = [14691, 15583, 17354, 17102, 16585, 17158, 17094, 18105,
                    18534, 19189, 19797, 21731, 22327, 23264, 22500, 25130,
                    25700, 26400, 27100, 27800, 28300]

    n = min(len(quarters), len(repo_rate), len(cpi_inflation), len(gdp_growth),
            len(forex_reserves_usd_bn), len(nifty50_qend))
    df = pd.DataFrame({
        "quarter": quarters[:n],
        "repo_rate": repo_rate[:n],
        "cpi_inflation_pct": cpi_inflation[:n],
        "gdp_growth_pct": gdp_growth[:n],
        "forex_reserves_usd_bn": forex_reserves_usd_bn[:n],
        "nifty50_qend": nifty50_qend[:n],
    })
    df.to_csv(path, index=False)
    return df


def load_data():
    os.makedirs("data", exist_ok=True)
    if os.path.exists(DATA_PATH):
        return pd.read_csv(DATA_PATH)
    return build_macro_dataset(DATA_PATH)


def compute_derived_metrics(df):
    d = df.copy()
    d["nifty_qoq_return_pct"] = d["nifty50_qend"].pct_change() * 100
    d["real_repo_rate"] = d["repo_rate"] - d["cpi_inflation_pct"]
    d["policy_stance"] = d["repo_rate"].diff().apply(
        lambda x: "Tightening" if x > 0 else ("Easing" if x < 0 else "Hold")
    )
    return d


def correlation_summary(d):
    cols = ["repo_rate", "cpi_inflation_pct", "gdp_growth_pct",
            "forex_reserves_usd_bn", "nifty_qoq_return_pct"]
    return d[cols].corr()


def policy_commentary(d):
    latest = d.iloc[-1]
    prior = d.iloc[-2]
    lines = []
    lines.append(f"Latest quarter ({latest['quarter']}): Repo rate at {latest['repo_rate']}%, "
                  f"CPI inflation at {latest['cpi_inflation_pct']}%, real policy rate "
                  f"{latest['real_repo_rate']:.1f}%.")
    if latest["repo_rate"] > prior["repo_rate"]:
        lines.append("RBI is in a tightening cycle — rate hikes typically precede a "
                      "near-term equity market correction before stabilizing.")
    elif latest["repo_rate"] < prior["repo_rate"]:
        lines.append("RBI has eased policy — historically supportive for equity valuations "
                      "via lower discount rates, with a lag of 1-2 quarters.")
    else:
        lines.append("RBI is on hold — market focus likely shifts to forward guidance and "
                      "inflation trajectory rather than the rate itself.")
    if latest["cpi_inflation_pct"] > 6.0:
        lines.append("CPI inflation is above RBI's upper tolerance band (6%) — expect a "
                      "hawkish bias in the next Monetary Policy Committee statement.")
    elif latest["cpi_inflation_pct"] < 4.0:
        lines.append("CPI inflation is below the 4% target midpoint — creates policy room "
                      "for accommodative measures if growth softens.")
    lines.append(f"Forex reserves at ${latest['forex_reserves_usd_bn']:.0f}Bn provide "
                 f"{'a strong' if latest['forex_reserves_usd_bn'] > 600 else 'an adequate'} "
                 f"external buffer against currency volatility.")
    return lines


def make_macro_chart(d, outpath):
    fig, axes = plt.subplots(2, 2, figsize=(12, 8))
    axes[0, 0].plot(d["quarter"], d["repo_rate"], marker="o", color="#1f6f4a")
    axes[0, 0].set_title("RBI Repo Rate (%)")
    axes[0, 0].tick_params(axis="x", rotation=90, labelsize=6)

    axes[0, 1].plot(d["quarter"], d["cpi_inflation_pct"], marker="o", color="#c0392b")
    axes[0, 1].axhline(6.0, color="red", linestyle="--", linewidth=1)
    axes[0, 1].axhline(4.0, color="green", linestyle="--", linewidth=1)
    axes[0, 1].set_title("CPI Inflation (%) vs RBI Target Band")
    axes[0, 1].tick_params(axis="x", rotation=90, labelsize=6)

    axes[1, 0].plot(d["quarter"], d["gdp_growth_pct"], marker="o", color="#3a6ea5")
    axes[1, 0].set_title("GDP Growth YoY (%)")
    axes[1, 0].tick_params(axis="x", rotation=90, labelsize=6)

    axes[1, 1].plot(d["quarter"], d["nifty50_qend"], marker="o", color="#d4af37")
    axes[1, 1].set_title("Nifty 50 — Quarter-End Close")
    axes[1, 1].tick_params(axis="x", rotation=90, labelsize=6)

    for ax in axes.flat:
        ax.grid(alpha=0.3)
    fig.suptitle("Macro-Policy Dashboard — India", fontsize=13)
    fig.tight_layout()
    fig.savefig(outpath, dpi=150)
    plt.close(fig)


def make_correlation_chart(corr, outpath):
    import seaborn as sns
    fig, ax = plt.subplots(figsize=(7, 6))
    sns.heatmap(corr, annot=True, cmap="coolwarm", center=0, fmt=".2f", ax=ax)
    ax.set_title("Macro Indicators vs Nifty 50 QoQ Return — Correlation")
    fig.tight_layout()
    fig.savefig(outpath, dpi=150)
    plt.close(fig)


def export_report(d, corr, commentary, outpath):
    with pd.ExcelWriter(outpath, engine="openpyxl") as writer:
        d.round(2).to_excel(writer, sheet_name="Macro Data", index=False)
        corr.round(2).to_excel(writer, sheet_name="Correlation Matrix")
        pd.DataFrame({"Policy Commentary": commentary}).to_excel(
            writer, sheet_name="Commentary", index=False
        )


def main():
    df = load_data()
    d = compute_derived_metrics(df)
    corr = correlation_summary(d)
    commentary = policy_commentary(d)

    make_macro_chart(d, "macro_trends.png")
    make_correlation_chart(corr, "policy_market_correlation.png")
    export_report(d, corr, commentary, "macro_dashboard_report.xlsx")

    print("=" * 60)
    print("RBI MACRO-POLICY & MARKET CORRELATION DASHBOARD")
    print("=" * 60)
    print(d[["quarter", "repo_rate", "cpi_inflation_pct", "gdp_growth_pct",
              "policy_stance"]].to_string(index=False))
    print("-" * 60)
    print("Correlation with Nifty 50 QoQ return:")
    print(corr["nifty_qoq_return_pct"].round(2).to_string())
    print("-" * 60)
    print("POLICY COMMENTARY:")
    for line in commentary:
        print(f"  • {line}")
    print("-" * 60)
    print("Outputs written: macro_trends.png, policy_market_correlation.png, macro_dashboard_report.xlsx")


if __name__ == "__main__":
    main()
