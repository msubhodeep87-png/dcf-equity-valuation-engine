"""
Streamlit Dashboard — RBI Macro-Policy & Market Correlation
Run with: streamlit run streamlit_app.py
"""

import streamlit as st
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from macro_dashboard import load_data, compute_derived_metrics, correlation_summary, policy_commentary

st.set_page_config(page_title="RBI Macro-Policy Dashboard", layout="wide")
st.title("🏦 RBI Macro-Policy & Market Correlation Dashboard")
st.caption("Repo Rate · CPI Inflation · GDP Growth · Forex Reserves · Nifty 50")

df = load_data()
d = compute_derived_metrics(df)
corr = correlation_summary(d)
commentary = policy_commentary(d)

latest = d.iloc[-1]
col1, col2, col3, col4 = st.columns(4)
col1.metric("Repo Rate", f"{latest['repo_rate']}%")
col2.metric("CPI Inflation", f"{latest['cpi_inflation_pct']}%")
col3.metric("GDP Growth YoY", f"{latest['gdp_growth_pct']}%")
col4.metric("Forex Reserves", f"${latest['forex_reserves_usd_bn']:.0f}Bn")

fig = make_subplots(rows=2, cols=2, subplot_titles=(
    "Repo Rate (%)", "CPI Inflation vs Target Band", "GDP Growth YoY (%)", "Nifty 50 Quarter-End"
))
fig.add_trace(go.Scatter(x=d["quarter"], y=d["repo_rate"], mode="lines+markers"), row=1, col=1)
fig.add_trace(go.Scatter(x=d["quarter"], y=d["cpi_inflation_pct"], mode="lines+markers"), row=1, col=2)
fig.add_hline(y=6, line_dash="dash", line_color="red", row=1, col=2)
fig.add_hline(y=4, line_dash="dash", line_color="green", row=1, col=2)
fig.add_trace(go.Scatter(x=d["quarter"], y=d["gdp_growth_pct"], mode="lines+markers"), row=2, col=1)
fig.add_trace(go.Scatter(x=d["quarter"], y=d["nifty50_qend"], mode="lines+markers"), row=2, col=2)
fig.update_layout(height=650, showlegend=False, template="plotly_dark")
st.plotly_chart(fig, use_container_width=True)

st.subheader("Correlation with Nifty 50 QoQ Return")
st.dataframe(corr.round(2))

st.subheader("Auto-Generated Policy Commentary")
for line in commentary:
    st.write(f"• {line}")

st.subheader("Full Macro Data")
st.dataframe(d.round(2))
