# Credit Risk / Loan Default Prediction Model

A binary classification model (Logistic Regression + XGBoost) that predicts loan default probability from borrower features — the core data-science workflow behind bank credit scoring and RBI-regulated NBFC underwriting.

## What it does
- Generates a realistic synthetic credit dataset (5,000 applicants: income, loan amount, DTI, credit history, delinquencies, employment length → default flag) so the project runs with zero external downloads
- Trains and compares **Logistic Regression** (the interpretable, regulator-friendly model banks still use for scorecards) against **XGBoost** (the higher-performance model used in modern underwriting)
- Evaluates both with **ROC-AUC**, precision/recall, and a feature importance ranking
- Outputs a scored applicant list bucketed into Low/Medium/High/Very High risk bands — the same structure as a real credit risk dashboard

## Why this matters for a finance role
Credit risk modeling sits at the center of banking, NBFC, and RBI Grade B (DEPR / regulatory) work — understanding probability of default (PD) models is core to Basel/RBI prudential norms. This project shows you can build, evaluate, and explain a PD model end-to-end, including the trade-off between interpretability (logistic regression, which regulators prefer) and performance (XGBoost).

## Tech stack
Python · pandas · numpy · scikit-learn · XGBoost · matplotlib

## Setup
```bash
pip install -r requirements.txt
python credit_risk_model.py
```
To use a real dataset (e.g. Kaggle's "Give Me Some Credit" or LendingClub), replace the `load_data()` function to read your CSV instead of `generate_synthetic_credit_data()`.

## Outputs
- `data/synthetic_credit_data.csv` — the dataset used
- `roc_curve.png` — model comparison (AUC for both models)
- `feature_importance.png` — XGBoost's top default drivers
- `credit_risk_report.xlsx` — model comparison metrics + top 200 highest-risk scored applicants

## How to talk about this in an interview
- "I built a credit default prediction model comparing Logistic Regression and XGBoost, evaluated on ROC-AUC, and used feature importance to identify debt-to-income and delinquency history as the strongest default predictors — consistent with how real underwriting models are validated."
- Be ready to explain: why **recall on the default class** matters more than overall accuracy for a lender (missing a defaulter is far costlier than a false alarm), what AUC actually measures (the model's ability to rank-order risk, not predict an exact probability), and why banks still keep logistic regression in production even when XGBoost scores higher — regulatory explainability under RBI/Basel model governance norms.
- If asked to extend it: add SHAP values for per-applicant explainability, calibrate probabilities (Platt scaling), or build a reject-inference layer for the population of declined applicants who were never observed to default.
